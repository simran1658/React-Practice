import Shivi from './Shivi';
function App() {
  return (
    <>
    <Shivi></Shivi>
    <h1>hello Shivani😎😎 </h1>
    </>
  );
}

export default App;
