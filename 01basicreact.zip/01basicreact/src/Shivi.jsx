function Shivi(){
    return (
    <h1>hey shivi</h1>
    )
}
export default Shivi